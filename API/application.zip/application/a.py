from selenium import webdriver
from time import sleep
# Iniciar el navegador
driver = webdriver.Chrome()

# Iniciar sesión y realizar otras acciones necesarias
driver.get('https://demoqa.com/nestedframes')
# Realizar el inicio de sesión utilizando Selenium
sleep(6)
# Guardar las cookies, localStorage y sessionStorage
cookies = driver.get_cookies()
local_storage = driver.execute_script("return window.localStorage;")
session_storage = driver.execute_script("return window.sessionStorage;")
print(cookies)
print(local_storage)
print(session_storage)
# Cerrar el navegador
driver.quit()

# En una sesión posterior
# Iniciar el navegador
driver = webdriver.Chrome()

# Cargar las cookies, localStorage y sessionStorage
driver.get('https://demoqa.com/nestedframes')
sleep(6)

for cookie in cookies:
    driver.add_cookie(cookie)

driver.execute_script("window.localStorage.clear();")
for key, value in local_storage.items():
    driver.execute_script(f"window.localStorage.setItem('{key}', '{value}');")

driver.execute_script("window.sessionStorage.clear();")
for key, value in session_storage.items():
    driver.execute_script(f"window.sessionStorage.setItem('{key}', '{value}');")

# Ahora, puedes realizar acciones automatizadas sin necesidad de volver a iniciar sesión

# Cerrar el navegador al final
driver.quit()
